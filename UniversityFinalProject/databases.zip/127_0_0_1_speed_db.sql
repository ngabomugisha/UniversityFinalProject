--
-- Database: `speed_db`
--
CREATE DATABASE IF NOT EXISTS `speed_db` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `speed_db`;

-- --------------------------------------------------------

--
-- Table structure for table `data1`
--

CREATE TABLE `data1` (
  `id` int(11) NOT NULL,
  `first` int(11) NOT NULL,
  `timeStamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `data1`
--

INSERT INTO `data1` (`id`, `first`, `timeStamp`) VALUES
(1, 0, '2019-06-29 11:02:20'),
(2, 0, '2019-06-29 11:14:51'),
(3, 0, '2019-06-29 11:15:06'),
(4, 0, '2019-06-29 12:09:07'),
(5, 0, '2019-06-29 12:09:13'),
(6, 0, '2019-07-04 06:51:14'),
(7, 0, '2019-07-04 06:51:31'),
(8, 0, '2019-07-04 06:52:09');

-- --------------------------------------------------------

--
-- Table structure for table `data2`
--

CREATE TABLE `data2` (
  `id2` int(11) NOT NULL,
  `last` int(11) NOT NULL,
  `timeStamp2` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `data2`
--

INSERT INTO `data2` (`id2`, `last`, `timeStamp2`) VALUES
(1, 0, '2019-06-29 12:18:20'),
(2, 0, '2019-06-29 12:18:41'),
(3, 0, '2019-06-29 13:21:11'),
(4, 0, '2019-06-29 13:21:55'),
(5, 0, '2019-06-29 13:35:31'),
(6, 0, '2019-06-29 13:35:31'),
(7, 0, '2019-07-04 06:51:32'),
(8, 0, '2019-07-04 06:52:09'),
(9, 0, '2019-07-04 06:56:36');

-- --------------------------------------------------------

--
-- Table structure for table `plate_record`
--

CREATE TABLE `plate_record` (
  `plate_id` int(11) NOT NULL,
  `plate` varchar(100) NOT NULL,
  `timeStamp3` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `plate_record`
--

INSERT INTO `plate_record` (`plate_id`, `plate`, `timeStamp3`) VALUES
(1, 'RAB123A\n', '2019-07-06 06:52:45'),
(2, 'RAB123A\n', '2019-07-06 06:52:45'),
(3, 'RAB123A\n', '2019-07-06 06:52:46'),
(4, 'RAB123A\n', '2019-07-06 06:52:46'),
(5, 'RAB123A\n', '2019-07-06 06:52:47'),
(6, 'RAB123A\n', '2019-07-06 06:52:47'),
(7, 'RAB123A\n', '2019-07-06 06:52:47');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `data1`
--
ALTER TABLE `data1`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `data2`
--
ALTER TABLE `data2`
  ADD PRIMARY KEY (`id2`);

--
-- Indexes for table `plate_record`
--
ALTER TABLE `plate_record`
  ADD PRIMARY KEY (`plate_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `data1`
--
ALTER TABLE `data1`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `data2`
--
ALTER TABLE `data2`
  MODIFY `id2` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `plate_record`
--
ALTER TABLE `plate_record`
  MODIFY `plate_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
